const {
  ActionRowBuilder,
  ButtonBuilder,
  ButtonStyle,
  EmbedBuilder,
  ModalBuilder,
  TextInputBuilder,
  TextInputStyle,
  ComponentType,
  InteractionType
} = require('discord.js');

module.exports = {
  name: 'embedwebhook',
  description: 'Crie um embed customizado e envie via webhook.',

  async execute(message, args, client) {
    message.delete()
    const embed = new EmbedBuilder()
      .setTitle('Titulo')
      .setDescription('Descrição')
      .setColor('Blurple');

    client.embeds.set(message.author.id, { embed, fields: [] });

    // Criar botões principais
    function createMainMenuRows(data) {
      const mainRow = new ActionRowBuilder().addComponents(
        new ButtonBuilder().setCustomId('edit_title').setLabel('Editar Título').setStyle(ButtonStyle.Primary),
        new ButtonBuilder().setCustomId('edit_description').setLabel('Editar Descrição').setStyle(ButtonStyle.Primary),
        new ButtonBuilder().setCustomId('add_field').setLabel('Adicionar Field').setStyle(ButtonStyle.Secondary),
        new ButtonBuilder().setCustomId('send_webhook').setLabel('Enviar').setStyle(ButtonStyle.Success)
      );

      // Pega todos os fields e cria botões pra editar
      const fieldButtons = data.fields.map((field, i) =>
        new ButtonBuilder().setCustomId(`edit_field_menu_${i}`).setLabel(`Editar Field ${i + 1}`).setStyle(ButtonStyle.Secondary)
      );

      const fieldRows = [];
      while (fieldButtons.length > 0) fieldRows.push(new ActionRowBuilder().addComponents(fieldButtons.splice(0, 5)));

      return [mainRow, ...fieldRows];
    }

    function createFieldEditRows(index) {
        const data = client.embeds.get(message.author.id);
        const field = data.fields[index];

        return [
            new ActionRowBuilder().addComponents(
                new ButtonBuilder()
                    .setCustomId(`edit_field_name_${index}`)
                    .setLabel('Editar Nome')
                    .setStyle(ButtonStyle.Primary),

            new ButtonBuilder()
                .setCustomId(`edit_field_value_${index}`)
                .setLabel('Editar Valor')
                .setStyle(ButtonStyle.Primary),

            new ButtonBuilder()
                .setCustomId(`edit_field_inline_${index}`)
                .setLabel(field.inline ? 'Inline: ON' : 'Inline: OFF')
                .setStyle(field.inline ? ButtonStyle.Success : ButtonStyle.Danger),

            new ButtonBuilder()
                .setCustomId('back_to_main')
                .setLabel('Voltar')
                .setStyle(ButtonStyle.Danger)
            )
        ];
    }

    const sentMessage = await message.channel.send({
      content: 'Menu principal de customização do embed:',
      embeds: [embed],
      components: createMainMenuRows(client.embeds.get(message.author.id))
    });

    const collector = sentMessage.createMessageComponentCollector({
      componentType: ComponentType.Button,
      time: 5 * 60 * 1000,
      filter: i => i.user.id === message.author.id
    });

    collector.on('collect', async interaction => {
      if (!interaction.isButton()) return;

      let data = client.embeds.get(message.author.id);
      if (!data) return interaction.reply({ content: 'Embed não encontrado.', ephemeral: true });

      let embed = EmbedBuilder.from(data.embed);

      // Aqui é onde pega os eventos dos cliques
      if (interaction.customId === 'edit_title') {
        // Editar o titulo
        const modal = new ModalBuilder()
          .setCustomId('modal_edit_title')
          .setTitle('Editar Título');
        const titleInput = new TextInputBuilder()
          .setCustomId('title_input')
          .setLabel('Novo título')
          .setStyle(TextInputStyle.Short)
          .setRequired(true)
          .setMaxLength(256)
          .setValue(embed.title || '');
        modal.addComponents(new ActionRowBuilder().addComponents(titleInput));
        await interaction.showModal(modal);
      }
      else if (interaction.customId === 'edit_description') {
        // Editar descrição
        const modal = new ModalBuilder()
          .setCustomId('modal_edit_description')
          .setTitle('Editar Descrição');
        const descInput = new TextInputBuilder()
          .setCustomId('desc_input')
          .setLabel('Nova descrição')
          .setStyle(TextInputStyle.Paragraph)
          .setRequired(true)
          .setMaxLength(4096)
          .setValue(embed.description || '');
        modal.addComponents(new ActionRowBuilder().addComponents(descInput));
        await interaction.showModal(modal);
      }
      else if (interaction.customId === 'add_field') {
        // Bagulho pra adicionar novo field
        const modal = new ModalBuilder()
          .setCustomId('modal_add_field')
          .setTitle('Adicionar fied');
        const nameInput = new TextInputBuilder()
          .setCustomId('field_name')
          .setLabel('Nome do field')
          .setStyle(TextInputStyle.Short)
          .setRequired(true)
          .setMaxLength(256);
        const valueInput = new TextInputBuilder()
          .setCustomId('field_value')
          .setLabel('Valor do field')
          .setStyle(TextInputStyle.Paragraph)
          .setRequired(true)
          .setMaxLength(1024);
        modal.addComponents(
          new ActionRowBuilder().addComponents(nameInput),
          new ActionRowBuilder().addComponents(valueInput)
        );
        await interaction.showModal(modal);
      }
      else if (interaction.customId.startsWith('edit_field_menu_')) {
        // Editar o field
        const index = parseInt(interaction.customId.split('_')[3]);
        if (index < 0 || index >= data.fields.length) {
          return interaction.reply({ content: 'Invalido.', ephemeral: true });
        }
        await interaction.update({
          content: `Editando field ${index + 1} - **${data.fields[index].name}**`,
          embeds: [embed],
          components: createFieldEditRows(index)
        });
      }
      else if (interaction.customId.startsWith('edit_field_name_')) {
        // Editar nome do field
        const index = parseInt(interaction.customId.split('_')[3]);
        if (index < 0 || index >= data.fields.length) {
          return interaction.reply({ content: 'Invalido.', ephemeral: true });
        }
        const modal = new ModalBuilder()
          .setCustomId(`modal_edit_field_name_${index}`)
          .setTitle(`Editar Nome do field ${index + 1}`);
        const nameInput = new TextInputBuilder()
          .setCustomId('field_name_input')
          .setLabel('Nome do field')
          .setStyle(TextInputStyle.Short)
          .setRequired(true)
          .setMaxLength(256)
          .setValue(data.fields[index].name);
        modal.addComponents(new ActionRowBuilder().addComponents(nameInput));
        await interaction.showModal(modal);
      }
      else if (interaction.customId.startsWith('edit_field_value_')) {
        // Editar value do field
        const index = parseInt(interaction.customId.split('_')[3]);
        if (index < 0 || index >= data.fields.length) {
          return interaction.reply({ content: 'Invalido.', ephemeral: true });
        }
        const modal = new ModalBuilder()
          .setCustomId(`modal_edit_field_value_${index}`)
          .setTitle(`Editar Valor do field ${index + 1}`);
        const valueInput = new TextInputBuilder()
          .setCustomId('field_value_input')
          .setLabel('Valor do field')
          .setStyle(TextInputStyle.Paragraph)
          .setRequired(true)
          .setMaxLength(1024)
          .setValue(data.fields[index].value);
        modal.addComponents(new ActionRowBuilder().addComponents(valueInput));
        await interaction.showModal(modal);
      }
      else if (interaction.customId.startsWith('edit_field_inline_')) {
        const index = parseInt(interaction.customId.split('_')[3]);
        if (index < 0 || index >= data.fields.length) {
            return interaction.reply({ content: 'Invalido.', ephemeral: true });
        }
        data.fields[index].inline = !data.fields[index].inline;
        embed.setFields(data.fields);
        data.embed = embed;

        await interaction.update({
            // content: `Field ${index + 1} inline toggled para: ${data.fields[index].inline}`,
            embeds: [embed],
            components: createFieldEditRows(index)
        });
        }
      else if (interaction.customId === 'back_to_main') {
        await interaction.update({
          content: 'Abaixo está o menu para você customizar o embed, com preview:',
          embeds: [embed],
          components: createMainMenuRows(data)
        });
      }
      else if (interaction.customId === 'send_webhook') {
        // Parte de enviar webhook
        const modal = new ModalBuilder()
          .setCustomId('modal_send_webhook')
          .setTitle('Enviar Webhook');
        const urlInput = new TextInputBuilder()
          .setCustomId('webhook_url')
          .setLabel('URL do webhook')
          .setStyle(TextInputStyle.Short)
          .setRequired(true);
        modal.addComponents(new ActionRowBuilder().addComponents(urlInput));
        await interaction.showModal(modal);
      }
    });

    client.on('interactionCreate', async interaction => {
      if (interaction.type !== InteractionType.ModalSubmit) return;
      if (interaction.user.id !== message.author.id) return; // só o autor pode mexer

      let data = client.embeds.get(message.author.id);
      if (!data) return interaction.reply({ content: 'Embed não encontrado.', ephemeral: true });

      let embed = EmbedBuilder.from(data.embed);

      // Editar título
      if (interaction.customId === 'modal_edit_title') {
        const newTitle = interaction.fields.getTextInputValue('title_input');
        embed.setTitle(newTitle);
        data.embed = embed;
        await interaction.reply({ content: `Título alterado para: ${newTitle}`, ephemeral: true });
        await sentMessage.edit({ embeds: [embed], components: createMainMenuRows(data) });
      }
      // Editar descrição
      else if (interaction.customId === 'modal_edit_description') {
        const newDesc = interaction.fields.getTextInputValue('desc_input');
        embed.setDescription(newDesc);
        data.embed = embed;
        await interaction.reply({ content: `Descrição alterada para: ${newDesc}`, ephemeral: true });
        await sentMessage.edit({ embeds: [embed], components: createMainMenuRows(data) });
      }
      // Adicionar field
      else if (interaction.customId === 'modal_add_field') {
        const name = interaction.fields.getTextInputValue('field_name');
        const value = interaction.fields.getTextInputValue('field_value');
        data.fields.push({ name, value, inline: false });
        embed.setFields(data.fields);
        data.embed = embed;
        await interaction.reply({ content: `Field "${name}" adicionado.`, ephemeral: true });
        await sentMessage.edit({ embeds: [embed], components: createMainMenuRows(data) });
      }
      // Editar nome do field
      else if (interaction.customId.startsWith('modal_edit_field_name_')) {
        const index = parseInt(interaction.customId.split('_')[4]);
        const newName = interaction.fields.getTextInputValue('field_name_input');
        data.fields[index].name = newName;
        embed.setFields(data.fields);
        data.embed = embed;
        await interaction.reply({ content: `Nome do field ${index + 1} atualizado.`, ephemeral: true });
        await sentMessage.edit({ embeds: [embed], components: createFieldEditRows(index) });
      }
      // Editar value do field
      else if (interaction.customId.startsWith('modal_edit_field_value_')) {
        const index = parseInt(interaction.customId.split('_')[4]);
        const newValue = interaction.fields.getTextInputValue('field_value_input');
        data.fields[index].value = newValue;
        embed.setFields(data.fields);
        data.embed = embed;
        await interaction.reply({ content: `Valor do field ${index + 1} atualizado.`, ephemeral: true });
        await sentMessage.edit({ embeds: [embed], components: createFieldEditRows(index) });
      }
      // Enviar webhook
      else if (interaction.customId === 'modal_send_webhook') {
        const webhookUrl = interaction.fields.getTextInputValue('webhook_url');
        try {
          const fetch = global.fetch || (await import('node-fetch')).default;
          await fetch(webhookUrl, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ embeds: [embed.toJSON()] })
          });

          await interaction.reply({ content: 'Webhook enviado com sucesso!', ephemeral: true });
          // Apagar depois de mandar a mensagem
          await sentMessage.delete().catch(() => {});
          client.embeds.delete(message.author.id);
        } catch (error) {
          await interaction.reply({ content: 'Falha ao enviar webhook: ' + error.message, ephemeral: true });
        }
      }
    });

    collector.on('end', () => {
      sentMessage.edit({ components: [] }).catch(() => {});
    });
  }
};